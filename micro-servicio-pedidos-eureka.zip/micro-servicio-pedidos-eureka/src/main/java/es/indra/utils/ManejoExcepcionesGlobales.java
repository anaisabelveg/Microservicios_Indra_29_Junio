package es.indra.utils;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ManejoExcepcionesGlobales {
	
	// Al igual que con try-catch podemos tener multiples catch
	// Aqui podemos tener varios metodos y que cada uno capture un tipo de excepcion
	
	// http://localhost:8002/crear/4765676/cantidad/10
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> errorNoExisteId(RuntimeException ex){
		return new ResponseEntity<String>("ID producto no existe", HttpStatus.NOT_FOUND);
	}

}
