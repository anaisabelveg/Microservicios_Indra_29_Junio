package es.indra.rest;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.entities.Producto;

@RestController
//@RequestMapping("/api")
@Validated  // Necesario para activar las reglas de validacion
public class ProductosREST {
	
	@Autowired  // Inyectamos un bean
	private IProductosBS bs;
	
	@Value("${server.port}")      // Para inyectar valores (tipos primitivos y String)
	private Integer port;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return bs.consultarTodos()
				.stream()
				.map(prod -> {
					prod.setPort(port);
					return prod;
				})
				.collect(Collectors.toList());
	}

	// http://localhost:8001/buscar/2
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") @Min(1) @Max(6) Long id) {
		Producto producto = bs.buscarProducto(id);
		
		// Si no ha encontrado el producto lanzamos una excepcion
		if (producto.getDescripcion() == null)
			throw new RuntimeException("Ese producto no existe");
		
		producto.setPort(port);
		return producto;
	}
}
