package es.indra.persistence;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import es.indra.entities.Producto;

// ctrl + shift + o

// Expongo este DAO como un servicio REST
@RepositoryRestResource(path = "productos", collectionResourceRel = "PRODUCTOS")
public interface ProductosDAO extends JpaRepository<Producto, Long>{
	
	// Ver todos los productos
	// http://localhost:8001/productos
	
	// Buscar un producto
	// http://localhost:8001/productos/3
	
	// Podemos crear metodos personalizados utilizando keywords
	// https://docs.spring.io/spring-data/jpa/reference/repositories/query-keywords-reference.html
	
	// Ver todos los metodos personalizados
	// http://localhost:8001/productos/search
	
	// http://localhost:8001/productos/search/findByDescripcion?descripcion=Monitor
	public List<Producto> findByDescripcion(String descripcion);
	
	// http://localhost:8001/productos/search/findByPrecioBetween?min=50&max=200
	public List<Producto> findByPrecioBetween(double min, double max);
	
	// http://localhost:8001/productos/search/findByPrecioBetweenOrderByDescripcion?min=50&max=200
	public List<Producto> findByPrecioBetweenOrderByDescripcion(double min, double max);
	
	// http://localhost:8001/productos/search/findByPrecioBetweenOrderByDescripcionDesc?min=50&max=200
	public List<Producto> findByPrecioBetweenOrderByDescripcionDesc(double min, double max);
	
	// http://localhost:8001/productos/search/miQuery?precio=150
	@Query("select p from Producto p where p.precio < ?1 ")
	public List<Producto> miQuery(double precio);

}
