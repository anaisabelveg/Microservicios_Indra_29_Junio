package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.indra.entities.Producto;
import es.indra.persistence.ProductosDAO;

/*
 * En Spring cualquier clase anotada con una de estas anotaciones, se reconoce como un bean de Spring
 * 		@Repository; repositorios de datos, dao, erp, ldap, ...etc
 * 		@Controller; controladores de Spring MVC
 * 		@Service; logica de negocio, business, servicios, ...
 * 		@Component; cuando la clase no es ninguna de las anteriores
 */

@Service   // Spring, quiero que me generes un bean de esta clase
public class ProductosBSImpl implements IProductosBS{
	
	@Autowired  // Inyectar un bean de tipo ProductosDAO
	private ProductosDAO dao;

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(Long id) {
		return dao.findById(id).orElse(new Producto());
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED,
			isolation = Isolation.SERIALIZABLE,
			rollbackFor = Exception.class)
	public Producto crearProducto(Producto producto) {
		return dao.save(producto);
	}

	@Override
	public String eliminarProducto(Long id) {
		dao.deleteById(id);
		return "Producto eliminado " + id;
	}

}
