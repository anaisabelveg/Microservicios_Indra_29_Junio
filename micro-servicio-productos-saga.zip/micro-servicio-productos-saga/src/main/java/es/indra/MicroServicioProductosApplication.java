package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class MicroServicioProductosApplication {

	// En los proyectos Spring Boot el metodo main se dedica exclusivamente a 
	// levantar el contexto Spring (crear el contenedor y crear todos los bean declarados)
	public static void main(String[] args) {
		SpringApplication.run(MicroServicioProductosApplication.class, args);
	}

}
