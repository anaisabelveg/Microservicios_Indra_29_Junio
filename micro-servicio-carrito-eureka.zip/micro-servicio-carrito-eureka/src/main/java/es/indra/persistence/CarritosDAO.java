package es.indra.persistence;

import org.springframework.data.mongodb.repository.MongoRepository;

import es.indra.models.Carrito;

// No necesito anotaciones, porque Spring Boot al detectar que hereda de xxxRepository
// lo genera como un bean de Spring
public interface CarritosDAO extends MongoRepository<Carrito, String>{
	
	public Carrito findByUsuario(String usuario);

}
