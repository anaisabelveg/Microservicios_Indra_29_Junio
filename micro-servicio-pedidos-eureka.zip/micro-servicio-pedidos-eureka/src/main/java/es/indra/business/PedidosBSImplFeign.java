package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import es.indra.clients.ProductosClienteFeign;
import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service
@Primary  // Doy preferencia para que inyecte este bean
public class PedidosBSImplFeign implements IPedidosBS {
	
	@Autowired
	private ProductosClienteFeign clienteFeign;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		/*
		 * Comunicacion sincrona entre microservicios utilizando OpenFeign
		 */

		// Buscar el producto con ese id
		Producto producto = clienteFeign.buscar(id);

		// Crear el pedido
		Pedido pedido = new Pedido(producto, cantidad);

		// Retornar el pedido
		return pedido;
	}

}
