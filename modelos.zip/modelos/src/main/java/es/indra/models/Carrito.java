package es.indra.models;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data  // getter, setter, equals, hashcode, toString
@NoArgsConstructor   // Constructor por defecto
public class Carrito {
	
	private String id;
	private String usuario;
	private List<Pedido> contenido = new ArrayList<Pedido>();
	private double importe;
	
	// Necesitamos un constructor sin el id
	public Carrito(String usuario, List<Pedido> contenido, double importe) {
		super();
		this.usuario = usuario;
		this.contenido = contenido;
		this.importe = importe;
	}
	
}
