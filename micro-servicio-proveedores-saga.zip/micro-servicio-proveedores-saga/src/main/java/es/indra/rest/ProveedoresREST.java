package es.indra.rest;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProveedoresBS;

@RestController
public class ProveedoresREST {
	
	private IProveedoresBS bs;

	public ProveedoresREST(IProveedoresBS bs) {
		super();
		this.bs = bs;
	}
	
	
	@PostMapping("/alta/{nombre}")
	public String alta(@PathVariable String nombre) {
		return bs.crearProveedor(nombre);
	}

}
