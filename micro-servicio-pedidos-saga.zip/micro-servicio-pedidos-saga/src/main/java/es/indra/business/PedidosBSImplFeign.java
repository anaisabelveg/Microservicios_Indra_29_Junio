package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import es.indra.clients.ProductosClienteFeign;
import es.indra.clients.ProveedoresClienteFeign;
import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service
@Primary  // Doy preferencia para que inyecte este bean
public class PedidosBSImplFeign implements IPedidosBS {
	
	@Autowired
	private ProductosClienteFeign clienteFeign;
	
	@Autowired
	private ProveedoresClienteFeign proveedoresClienteFeign;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		/*
		 * Comunicacion sincrona entre microservicios utilizando OpenFeign
		 */

		// Buscar el producto con ese id
		Producto producto = clienteFeign.buscar(id);

		// Crear el pedido
		Pedido pedido = new Pedido(producto, cantidad);

		// Retornar el pedido
		return pedido;
	}

	@Override
	public String pruebaTransaccion(String descripcion, double precio, String nombreProveedor) {
		String mensaje = "";
		Producto producto = null;
		
		try {
			// Dar de alta el producto
			producto = clienteFeign.nuevo(descripcion, precio);
			
			// Dar de alta el proveedor
			proveedoresClienteFeign.alta(nombreProveedor);
			
			mensaje = "Todo ha ido bien, transacciones completadas";
		} catch (Exception e) {
			// Deshacer la transaccion, eliminamos el producto
			String msg = clienteFeign.eliminar(producto.getID());
			mensaje = "Transaccion deshecha " + msg;
		}
		
		
		return mensaje;
	}

}
