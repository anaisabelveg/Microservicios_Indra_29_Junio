package es.indra.business;

import java.util.List;

import org.springframework.stereotype.Service;

import es.indra.clients.PedidosClienteFeign;
import es.indra.models.Carrito;
import es.indra.models.Pedido;
import es.indra.persistence.CarritosDAO;

@Service
public class CarritoBSImpl implements ICarritoBS{
	
	/*
	 * Tenemos 2 formas de inyectar un bean:
	 * 		- @Autowired 
	 * 		- Por el constructor (Recomendacion en versiones actuales de Spring)
	 * */
	private CarritosDAO dao;
	private PedidosClienteFeign clienteFeign;
	
	// Los parametros dao y clienteFeign son inyectados
	public CarritoBSImpl(CarritosDAO dao, PedidosClienteFeign clienteFeign) {  
		super();
		this.dao = dao;
		this.clienteFeign = clienteFeign;
	}
	
	@Override
	public Carrito agregarPedido(Long id, Integer cantidad, String usuario) {
		// Crear el pedido en el micro-servicio-pedidos
		Pedido pedido = clienteFeign.crear(id, cantidad);
		
		// Lo agregamos al carrito de ese usuario
		Carrito carrito = consultar(usuario);
		carrito.getContenido().add(pedido);
		
		// Modificar el importe del carrito
		double importePedido = pedido.getProducto().getPrecio() * pedido.getCantidad();
		carrito.setImporte(carrito.getImporte() + importePedido);
		
		// Actualizar el carrito en MongoDB y lo retornamos
		return dao.save(carrito);
	}
	
	@Override
	public Carrito eliminarPedido(Long id, String usuario) {
		Carrito carrito = consultar(usuario);
		List<Pedido> contenido = carrito.getContenido();
		
		// Solo borro el primer pedido que encuentre con ese id de producto
		Pedido encontrado = contenido.stream()
				.filter(ped -> ped.getProducto().getID() == id)
				.findFirst()
				.get();
		contenido.remove(encontrado);
		
		// Modificar el importe del pedido
		double importePedido = encontrado.getProducto().getPrecio() * encontrado.getCantidad();
		carrito.setImporte(carrito.getImporte() - importePedido);
		
		// Actualizar el carrito en MongoDB y lo retornamos
		return dao.save(carrito);
	}

	@Override
	public Carrito crear(String usuario) {
		// Solo creamos el carrito si no existe otro para ese usuario
		Carrito carrito = consultar(usuario);
		
		if (carrito == null) {
			carrito = new Carrito();
			carrito.setUsuario(usuario);
			return dao.save(carrito);
		}
		
		return carrito;
	}

	@Override
	public Carrito consultar(String usuario) {
		return dao.findByUsuario(usuario);
	}
	
}
