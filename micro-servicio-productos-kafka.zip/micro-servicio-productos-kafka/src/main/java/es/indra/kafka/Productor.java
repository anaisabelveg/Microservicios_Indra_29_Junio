package es.indra.kafka;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class Productor {
	
	private KafkaTemplate<String, String> kafkaTemplate;

	public Productor(KafkaTemplate<String, String> kafkaTemplate) {
		super();
		this.kafkaTemplate = kafkaTemplate;
	}
	
	public void enviarComentario(String comentario) {
		kafkaTemplate.send("indra-cluster", comentario);
	}

}
